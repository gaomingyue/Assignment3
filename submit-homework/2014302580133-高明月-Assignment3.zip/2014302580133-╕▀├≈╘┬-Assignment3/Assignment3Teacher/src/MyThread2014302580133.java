import org.jsoup.Jsoup;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.sql.SQLException;


import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;

public class MyThread2014302580133 extends Thread{
	
		private String address;
		private String database;
		public MyThread2014302580133(String address,String database){
			this.address=address;
			this.database=database;
		}
		String name;
		String background;
		 String direction;
		 String phone;
		 String email;
		public void run(){

			Document doc;
			try{				
				//��JSOUP����HTML	
			doc = Jsoup.connect(address).get();
			doc = Jsoup.connect(address)
					  .data("query", "Java")
					  .userAgent("Mozilla")
					  .cookie("auth", "token")
					  .timeout(3000)
					  .post();
			//��������ȫ����ȡ����
			
			//��ȡ��ʦ��������h3Ϊ��ǩ��ȡ
			 Elements elements1 = doc.select("h3");
			 name = elements1.get(0).text();
		System.out.println(name);
		
		
		Elements elements2=doc.select("p");
		String information=elements2.get(0).text();
		String[] strarray=information.split(" ");
		background=strarray[0]+strarray[1]+strarray[2];
		direction=strarray[4];
		System.out.println("ѧ����"+strarray[0]+strarray[1]+strarray[2]);
		System.out.println("�о�����"+strarray[4]);
		Pattern p1 = null;
		Pattern p2 = null;//�������ʽ      
		Matcher m1= null; 
		Matcher m2= null;//�������ַ���  
		boolean b1 = false;
		boolean b2 = false;
		for(int i=5;i<strarray.length;i++){
			//System.out.println(strarray[i]);
			
			//�������ʽ��ʾ��һλ��1���ڶ�λΪ3��5����βΪ9λ���ֵ�һ������
		    p1 = Pattern.compile("\\d{3}-\\d{8}|\\d{11}|\\+\\d{2}-\\d{11}");
		m1 = p1.matcher(strarray[i]);
		b1 = m1.matches();   
		if(b1)	
			{
			System.out.println("�ֻ����룺"+strarray[i]);//�����true 
			phone=strarray[i];
			}
 
		p2=Pattern.compile("\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*");
		m2 = p2.matcher(strarray[i]);
		b2 = m2.matches(); 
		if(b2)	
		{
		System.out.println("���䣺"+strarray[i]);
		email=strarray[i];
		}
		}
		//System.out.println(information);
		System.out.println("     ");

		
		 Connection connect;
	
				connect = DriverManager.getConnection(database,"root","gaomingyue131553");
				 Statement stmt = connect.createStatement();
				// stmt.execute("set names gb2312");
			      String sql;
			      sql = "insert into teacher(NAME,BACKGROUND,DIRECTION,PHONE,EMAIL) "
		                		+ "values('"+name+"','"+background+"','"+direction+"','"+phone+"','"+email+"')";
			     
			      stmt.executeUpdate(sql);		  
			
			} catch (IOException e) {
				e.printStackTrace();
			}	catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    
			
		}
	}
	
import java.io.IOException;
import java.util.Iterator;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

//import MyThread.ThreadTest;

public class Main2014302580133 {
	public static void main(String[] args) throws Exception{
		
		
		try{						
			//��JSOUP����HTML
			Document doc1;
		doc1 = Jsoup.connect("http://staff.whu.edu.cn/?key=&title=0&showhomepage=0&college=�����ѧԺ&cid=211&lang=cn").get();
		doc1 = Jsoup.connect("http://staff.whu.edu.cn/?key=&title=0&showhomepage=0&college=�����ѧԺ&cid=211&lang=cn")
				  .data("query", "Java")
				  .userAgent("Mozilla")
				  .cookie("auth", "token")
				  .timeout(3000)
				  .post();

		
		int i=-1;
		String[] aURL = new String[60];
		String[] URL = new String[11];
		Element body = doc1.body();
		Elements elements=body.select("a");
		for (Iterator it = elements.iterator(); it.hasNext();) {
			   Element e = (Element) it.next();
			   i++;
			   aURL[i]=e.attr("href");

			  }
for(int j=0;j<11;j++){
	URL[j]=aURL[j+44];
	// System.out.println(URL[j]);
	}


System.out.println("���߳���ȡ��ʦ��Ϣ���������ݿ⣺");
long singlebegin=System.currentTimeMillis();
mysqlConnection2014302580133 connection2=new mysqlConnection2014302580133("jdbc:mysql://localhost:3306/siginalteacher","root","gaomingyue131553");
connection2.run();
String dasebase2="jdbc:mysql://localhost:3306/siginalteacher";
		MyThread2014302580133 tb1=new MyThread2014302580133("http://staff.whu.edu.cn/"+URL[1],dasebase2);
		tb1.run();	
		//sql = "insert into student(NO,name,background,direction,phone,email) values('1',t1.name,t1.background,t1.direction,t1.phone,t1.email)";
		 //result = stmt.executeUpdate(sql);
		MyThread2014302580133 tb3=new MyThread2014302580133("http://staff.whu.edu.cn/"+URL[3],dasebase2);
		tb3.run();
		MyThread2014302580133 tb6=new MyThread2014302580133("http://staff.whu.edu.cn/"+URL[6],dasebase2);
		tb6.run();
		MyThread2014302580133 tb7=new MyThread2014302580133("http://staff.whu.edu.cn/"+URL[7],dasebase2);
		tb7.run();
		MyThread2014302580133 tb9=new MyThread2014302580133("http://staff.whu.edu.cn/"+URL[9],dasebase2);
		tb9.run();
		MyThread2014302580133 tb10=new MyThread2014302580133("http://staff.whu.edu.cn/"+URL[10],dasebase2);
		tb10.run();      
long singleover=System.currentTimeMillis();


System.out.println("���߳���ȡ��ʦ��Ϣ���������ݿ⣺");
long multibegin=System.currentTimeMillis();
mysqlConnection2014302580133 connection1=new mysqlConnection2014302580133("jdbc:mysql://localhost:3306/teacherinformation","root","gaomingyue131553");
connection1.run();
String dasebase1="jdbc:mysql://localhost:3306/teacherinformation";
		MyThread2014302580133 t1=new MyThread2014302580133("http://staff.whu.edu.cn/"+URL[1],dasebase1);
		t1.start();	
		//sql = "insert into student(NO,name,background,direction,phone,email) values('1',t1.name,t1.background,t1.direction,t1.phone,t1.email)";
		 //result = stmt.executeUpdate(sql);
		MyThread2014302580133 t3=new MyThread2014302580133("http://staff.whu.edu.cn/"+URL[3],dasebase1);
		t3.start();
		MyThread2014302580133 t6=new MyThread2014302580133("http://staff.whu.edu.cn/"+URL[6],dasebase1);
		t6.start();
		MyThread2014302580133 t7=new MyThread2014302580133("http://staff.whu.edu.cn/"+URL[7],dasebase1);
		t7.start();
		MyThread2014302580133 t9=new MyThread2014302580133("http://staff.whu.edu.cn/"+URL[9],dasebase1);
		t9.start();
		MyThread2014302580133 t10=new MyThread2014302580133("http://staff.whu.edu.cn/"+URL[10],dasebase1);
		t10.start();
 long multiover=System.currentTimeMillis();
		      
 
		 System.out.println("���߳���ȡ���������ݿ���ʱ"+(singleover-singlebegin)+"����");
		 System.out.println("���߳���ȡ���������ݿ���ʱ"+(multiover-multibegin)+"����");
		} catch (IOException e) {
			e.printStackTrace();
		}/*catch (SQLException e) {
          System.out.println("MySQL��������");
            e.printStackTrace();
	}*/
	catch (Exception e) {
	            e.printStackTrace();
		 } 
	}
}
